const express = require("express");

const app = express();

const port = 3699;

var mysql = require('mysql');
var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "root",
  database: "rent-book",
  port: 3306
});

app.get("/list",(req,res)=>{
    var qry_select="select * from rent_form"
    connection.query(qry_select, function(err, rows, fields) {
        if (err) throw err
        res.send(rows)
        console.log(rows.length)
    })
})

app.get('/',(req, res)=>{

    res.send("Rent-A-Book")
  
  });
  
  
   
  
  app.listen(port, ()=>{
  
      console.log(`Employee project app listening at http://localhost:${port}`)
  
  });
 
